<template>
    <div>
        <h2>Profile Management</h2>
        <router-view></router-view>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
