<template>
    <section>
        <div class="card">
            <div class="card-header d-flex flex-wrap justify-content-between">
                <h4 class="text-capitalise">Create</h4>
                <ul>
                    <li>
                        <a href="#" class="btn btn-outline-info"><i class="fa fa-arrow-left"></i> All</a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <form action="#">
                    <div class="form-group mb-3">
                        <label for="title" class="text-capitalize">title</label>
                        <input type="text" id="title" name="title" class="form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="title" class="text-capitalize">title</label>
                        <input type="text" id="title" name="title" class="form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="title" class="text-capitalize">title</label>
                        <input type="text" id="title" name="title" class="form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="title" class="text-capitalize">title</label>
                        <input type="text" id="title" name="title" class="form-control">
                    </div>
                    <div class="text-center">
                        <button class="btn btn-info"><i class="fa fa-sign-in"></i> submit</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>
