<!DOCTYPE HTML>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <title>T.A.D.A</title>

    <link rel="stylesheet" type="text/css" href="/contents/website/styles/bootstrap.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/contents/website/fonts/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"/>
    <link rel="stylesheet" type="text/css" href="/contents/website/custom.css">
    <!-- <link rel="manifest" href="_manifest.json"> -->
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <?php echo $__env->yieldPushContent('ccss'); ?>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            onOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        window.s_alert = (icon, title) => {
            Toast.fire({
                icon: icon,
                title: title,
            })
        }
    </script>
</head>

<body class="theme-light" data-highlight="highlight-red">

    <div id="TadaAppBody">
        
        <tada-app></tada-app>
    </div>


    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
    </form>

    <link href="/contents/website/styles/select2.css" rel="stylesheet" />
    <script src="/contents/website/scripts/jq.js"></script>
    <script src="/js/vue_tada_management.js"></script>
    <script src="/contents/website/scripts/custom.js"></script>

</body>
<?php /**PATH D:\xampp\htdocs\Earth_Face_Projects\tada_laravel_vue\resources\views/tada/tada_wrapper.blade.php ENDPATH**/ ?>