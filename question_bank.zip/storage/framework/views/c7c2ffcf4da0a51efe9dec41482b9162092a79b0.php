<?php $__env->startSection('content'); ?>
<div id="BurgerManagementAppBody">
    <burger-management-app user="<?php echo e(auth()->user()); ?>"></burger-management-app>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\personal\burger_maker\resources\views/home.blade.php ENDPATH**/ ?>