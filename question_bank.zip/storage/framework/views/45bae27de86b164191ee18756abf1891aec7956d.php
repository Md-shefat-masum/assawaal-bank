<?php $__env->startSection('contents'); ?>

    <!-- About Part Start  -->
    <section id="about" class="py-5">
        <div class="container py-5">
            <h2>Menu List</h2>
            <br>
            <br>
            <div class="row">
                <?php $__currentLoopData = \App\Models\FoodManu::select('id','title','thumb_image')->where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 mb-4">
                        <div class="about_item">
                            <div class="about_icon text-center">
                                <img class="w-100" src="<?php echo e($item->thumb_image); ?>" alt="about-icon2.png">
                            </div>
                            <div class="about_txt text-center">
                                <h3><?php echo e($item->title); ?></h3>
                                <div class="offer_btn_slide">
                                    <a class="mx-0" href="<?php echo e(route('create_menu',$item->id)); ?>">Create Order</a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- About Part End  -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('burger_maker.burger_wrapper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\personal\burger_maker\resources\views/burger_maker/pages/frontend/menu.blade.php ENDPATH**/ ?>