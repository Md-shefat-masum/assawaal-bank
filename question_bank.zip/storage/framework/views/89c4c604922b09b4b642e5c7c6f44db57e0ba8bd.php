your login verification code is: <?php echo e(session()->get('verification')['code']); ?>

<?php /**PATH D:\xampp\htdocs\personal\question_bank\resources\views/mail/verification_code.blade.php ENDPATH**/ ?>