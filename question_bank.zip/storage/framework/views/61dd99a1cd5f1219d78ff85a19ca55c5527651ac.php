<table class="st-Background" bgcolor="#f6f9fc" border="0" cellpadding="0" cellspacing="0" width="100%" style="border: 0; margin: 0; padding: 0;">
    <tbody>
        <tr>
            <td style="border: 0; margin: 0; padding: 0;">
                <!-- Wrapper -->
                <table class="st-Wrapper" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="600" style="border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; margin: 0 auto; min-width: 600px;">
                    <tbody>
                        <tr>
                            <td style="border: 0; margin: 0; padding: 0;">
                                <table class="st-Preheader st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td
                                                align="center"
                                                height="0"
                                                style="
                                                    border: 0;
                                                    margin: 0;
                                                    padding: 0;
                                                    color: #ffffff;
                                                    display: none !important;
                                                    font-size: 1px;
                                                    line-height: 1px;
                                                    max-height: 0;
                                                    max-width: 0;
                                                    mso-hide: all !important;
                                                    opacity: 0;
                                                    overflow: hidden;
                                                    visibility: hidden;
                                                "
                                            >
                                                <span class="st-Delink st-Delink--preheader" style="color: #ffffff; text-decoration: none;">
                                                    Receipt from Food Maker [#1762-2197] Amount paid ৳<?php echo e($order->total_amount); ?>.00 Date paid <?php echo e(\Carbon\Carbon::parse($order->data)->format('d/m/y, h:i a')); ?>


                                                    <!-- Prevents elements showing up in email client preheader text -->
                                                    ‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;‌&nbsp;
                                                    <!-- /Prevents elements showing up in email client preheader text -->
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <div style="background-color: #f6f9fc; padding-top: 20px;">
                                    <table dir="ltr" class="Section Header" width="100%" style="border: 0; border-collapse: collapse; margin: 0; padding: 0; background-color: #ffffff;">
                                        <tbody>
                                            <tr>
                                                <td
                                                    class="Header-left Target"
                                                    style="
                                                        background-color: #525f7f;
                                                        border: 0;
                                                        border-collapse: collapse;
                                                        margin: 0;
                                                        padding: 0;
                                                        -webkit-font-smoothing: antialiased;
                                                        -moz-osx-font-smoothing: grayscale;
                                                        font-size: 0;
                                                        line-height: 0px;
                                                        mso-line-height-rule: exactly;
                                                        background-size: 100% 100%;
                                                        border-top-left-radius: 5px;
                                                    "
                                                    align="right"
                                                    height="156"
                                                    valign="bottom"
                                                    width="252"
                                                >
                                                    <a href="" target="_blank" style="-webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; outline: 0; text-decoration: none;">
                                                        <img
                                                            alt=""
                                                            height="156"
                                                            width="252"
                                                            src="https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Left.png"
                                                            style="display: block; border: 0; line-height: 100%; width: 100%;"
                                                        />
                                                    </a>
                                                </td>
                                                <td
                                                    class="Header-icon Target"
                                                    style="
                                                        background-color: #525f7f;
                                                        border: 0;
                                                        border-collapse: collapse;
                                                        margin: 0;
                                                        padding: 0;
                                                        -webkit-font-smoothing: antialiased;
                                                        -moz-osx-font-smoothing: grayscale;
                                                        font-size: 0;
                                                        line-height: 0px;
                                                        mso-line-height-rule: exactly;
                                                        background-size: 100% 100%;
                                                        width: 96px !important;
                                                    "
                                                    align="center"
                                                    height="156"
                                                    valign="bottom"
                                                >
                                                    <a href="" target="_blank" style="-webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; outline: 0; text-decoration: none;">
                                                        <img
                                                            alt=""
                                                            height="156"
                                                            width="96"
                                                            src="https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Icon--empty.png"
                                                            style="display: block; border: 0; line-height: 100%;"
                                                        />
                                                    </a>
                                                </td>
                                                <td
                                                    class="Header-right Target"
                                                    style="
                                                        background-color: #525f7f;
                                                        border: 0;
                                                        border-collapse: collapse;
                                                        margin: 0;
                                                        padding: 0;
                                                        -webkit-font-smoothing: antialiased;
                                                        -moz-osx-font-smoothing: grayscale;
                                                        font-size: 0;
                                                        line-height: 0px;
                                                        mso-line-height-rule: exactly;
                                                        background-size: 100% 100%;
                                                        border-top-right-radius: 5px;
                                                    "
                                                    align="left"
                                                    height="156"
                                                    valign="bottom"
                                                    width="252"
                                                >
                                                    <a href="" target="_blank" style="-webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; outline: 0; text-decoration: none;">
                                                        <img
                                                            alt=""
                                                            height="156"
                                                            width="252"
                                                            src="https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Right.png"
                                                            style="display: block; border: 0; line-height: 100%; width: 100%;"
                                                        />
                                                    </a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <table class="st-Copy st-Copy--caption st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td
                                                class="Content Title-copy Font Font--title"
                                                align="center"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    width: 472px;
                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                    mso-line-height-rule: exactly;
                                                    vertical-align: middle;
                                                    color: #32325d;
                                                    font-size: 24px;
                                                    line-height: 32px;
                                                "
                                            >
                                                Receipt from Food Maker
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--stacked" colspan="3" height="12" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Copy st-Copy--caption st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td
                                                class="Content Title-copy Font Font--title"
                                                align="center"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    width: 472px;
                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                    mso-line-height-rule: exactly;
                                                    vertical-align: middle;
                                                    color: #8898aa;
                                                    font-size: 15px;
                                                    line-height: 18px;
                                                "
                                            >
                                                Receipt #<?php echo e(rand(1000,9999)); ?>-<?php echo e($order->id); ?>-<?php echo e(rand(1000,9999)); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--stacked" colspan="3" height="12" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Spacer st-Spacer--standalone st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                        <tr>
                                            <td height="20" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Copy st-Copy--standalone st-Copy--caption" border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                class="st-Font st-Font--caption"
                                                style="
                                                    border: 0;
                                                    margin: 0;
                                                    padding: 0;
                                                    color: #8898aa;
                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                    font-size: 12px;
                                                    font-weight: bold;
                                                    line-height: 16px;
                                                    text-transform: uppercase;
                                                "
                                            ></td>
                                            <td
                                                width="64"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    color: #ffffff;
                                                    font-size: 1px;
                                                    line-height: 1px;
                                                    mso-line-height-rule: exactly;
                                                "
                                            >
                                                &nbsp;
                                            </td>
                                            <td class="DataBlocks-item" valign="top" style="border: 0; border-collapse: collapse; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;">
                                                <table style="border: 0; border-collapse: collapse; margin: 0; padding: 0;">
                                                    <tbody>
                                                        <tr>
                                                            <td
                                                                class="Font Font--caption Font--uppercase Font--mute Font--noWrap"
                                                                style="
                                                                    border: 0;
                                                                    border-collapse: collapse;
                                                                    margin: 0;
                                                                    padding: 0;
                                                                    -webkit-font-smoothing: antialiased;
                                                                    -moz-osx-font-smoothing: grayscale;
                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                    mso-line-height-rule: exactly;
                                                                    vertical-align: middle;
                                                                    color: #8898aa;
                                                                    font-size: 12px;
                                                                    line-height: 16px;
                                                                    white-space: nowrap;
                                                                    font-weight: bold;
                                                                    text-transform: uppercase;
                                                                "
                                                            >
                                                                Amount paid
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td
                                                                class="Font Font--body Font--noWrap"
                                                                style="
                                                                    border: 0;
                                                                    border-collapse: collapse;
                                                                    margin: 0;
                                                                    padding: 0;
                                                                    -webkit-font-smoothing: antialiased;
                                                                    -moz-osx-font-smoothing: grayscale;
                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                    mso-line-height-rule: exactly;
                                                                    vertical-align: middle;
                                                                    color: #525f7f;
                                                                    font-size: 15px;
                                                                    line-height: 24px;
                                                                    white-space: nowrap;
                                                                "
                                                            >
                                                                ৳<?php echo e($order->total_amount); ?>

                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td
                                                width="20"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    color: #ffffff;
                                                    font-size: 1px;
                                                    line-height: 1px;
                                                    mso-line-height-rule: exactly;
                                                "
                                            >
                                                &nbsp;
                                            </td>
                                            <td class="DataBlocks-item" valign="top" style="border: 0; border-collapse: collapse; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;">
                                                <table style="border: 0; border-collapse: collapse; margin: 0; padding: 0;">
                                                    <tbody>
                                                        <tr>
                                                            <td
                                                                class="Font Font--caption Font--uppercase Font--mute Font--noWrap"
                                                                style="
                                                                    border: 0;
                                                                    border-collapse: collapse;
                                                                    margin: 0;
                                                                    padding: 0;
                                                                    -webkit-font-smoothing: antialiased;
                                                                    -moz-osx-font-smoothing: grayscale;
                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                    mso-line-height-rule: exactly;
                                                                    vertical-align: middle;
                                                                    color: #8898aa;
                                                                    font-size: 12px;
                                                                    line-height: 16px;
                                                                    white-space: nowrap;
                                                                    font-weight: bold;
                                                                    text-transform: uppercase;
                                                                "
                                                            >
                                                                Date paid
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td
                                                                class="Font Font--body Font--noWrap"
                                                                style="
                                                                    border: 0;
                                                                    border-collapse: collapse;
                                                                    margin: 0;
                                                                    padding: 0;
                                                                    -webkit-font-smoothing: antialiased;
                                                                    -moz-osx-font-smoothing: grayscale;
                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                    mso-line-height-rule: exactly;
                                                                    vertical-align: middle;
                                                                    color: #525f7f;
                                                                    font-size: 15px;
                                                                    line-height: 24px;
                                                                    white-space: nowrap;
                                                                "
                                                            >
                                                                <?php if($order->payment_status == 'paid'): ?>
                                                                    <?php echo e(\Carbon\Carbon::parse($order->data)->format('d/m/y, h:i A')); ?>

                                                                <?php else: ?>
                                                                    pending
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td
                                                width="20"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    color: #ffffff;
                                                    font-size: 1px;
                                                    line-height: 1px;
                                                    mso-line-height-rule: exactly;
                                                "
                                            >
                                                &nbsp;
                                            </td>
                                            <td class="DataBlocks-item" valign="top" style="border: 0; border-collapse: collapse; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;">
                                                <table style="border: 0; border-collapse: collapse; margin: 0; padding: 0;">
                                                    <tbody>
                                                        <tr>
                                                            <td
                                                                class="Font Font--caption Font--uppercase Font--mute Font--noWrap"
                                                                style="
                                                                    border: 0;
                                                                    border-collapse: collapse;
                                                                    margin: 0;
                                                                    padding: 0;
                                                                    -webkit-font-smoothing: antialiased;
                                                                    -moz-osx-font-smoothing: grayscale;
                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                    mso-line-height-rule: exactly;
                                                                    vertical-align: middle;
                                                                    color: #8898aa;
                                                                    font-size: 12px;
                                                                    line-height: 16px;
                                                                    white-space: nowrap;
                                                                    font-weight: bold;
                                                                    text-transform: uppercase;
                                                                "
                                                            >
                                                                Payment method
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td
                                                                class="Font Font--body Font--noWrap"
                                                                style="
                                                                    border: 0;
                                                                    border-collapse: collapse;
                                                                    margin: 0;
                                                                    padding: 0;
                                                                    -webkit-font-smoothing: antialiased;
                                                                    -moz-osx-font-smoothing: grayscale;
                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                    mso-line-height-rule: exactly;
                                                                    vertical-align: middle;
                                                                    color: #525f7f;
                                                                    font-size: 15px;
                                                                    line-height: 24px;
                                                                    white-space: nowrap;
                                                                "
                                                            >
                                                                <span>
                                                                    - <?php echo e($order->payment_type); ?>

                                                                </span>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td
                                                width="64"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    color: #ffffff;
                                                    font-size: 1px;
                                                    line-height: 1px;
                                                    mso-line-height-rule: exactly;
                                                "
                                            >
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Spacer st-Spacer--standalone st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                        <tr>
                                            <td height="32" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Copy st-Copy--caption st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                            <td
                                                class="st-Font st-Font--caption"
                                                style="
                                                    border: 0;
                                                    margin: 0;
                                                    padding: 0;
                                                    color: #8898aa;
                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                    font-size: 12px;
                                                    line-height: 16px;
                                                    text-transform: uppercase;
                                                "
                                            >
                                                <span class="st-Delink" style="border: 0; margin: 0; padding: 0; font-weight: bold;">
                                                    Summary
                                                </span>
                                            </td>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--stacked" colspan="3" height="12" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table class="st-Blocks st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--stacked" colspan="3" height="4" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--kill" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                            <td style="border: 0; margin: 0; padding: 0;">
                                                <table class="st-Blocks-inner" bgcolor="#f6f9fc" border="0" cellpadding="0" cellspacing="0" style="border-radius: 5px;" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="border: 0; margin: 0; padding: 0;">
                                                                <table class="st-Blocks-item" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td
                                                                                class="st-Spacer st-Spacer--blocksItemEnds"
                                                                                colspan="3"
                                                                                height="12"
                                                                                style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;"
                                                                            >
                                                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="16">
                                                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                                                            </td>
                                                                            <td
                                                                                class="st-Blocks-item-cell st-Font st-Font--body"
                                                                                style="
                                                                                    border: 0;
                                                                                    margin: 0;
                                                                                    padding: 0;
                                                                                    color: #525f7f;
                                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                                    font-size: 16px;
                                                                                    line-height: 24px;
                                                                                "
                                                                            >
                                                                                <table style="padding-left: 5px; padding-right: 5px;" width="100%">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td></td>
                                                                                        </tr>
                                                                                        <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                                            <tr>
                                                                                                <td
                                                                                                    class="Table-description Font Font--body"
                                                                                                    style="
                                                                                                        border: 0;
                                                                                                        border-collapse: collapse;
                                                                                                        margin: 0;
                                                                                                        padding: 0;
                                                                                                        -webkit-font-smoothing: antialiased;
                                                                                                        -moz-osx-font-smoothing: grayscale;
                                                                                                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                                                        mso-line-height-rule: exactly;
                                                                                                        vertical-align: middle;
                                                                                                        color: #525f7f;
                                                                                                        font-size: 15px;
                                                                                                        line-height: 24px;
                                                                                                        width: 100%;
                                                                                                    "
                                                                                                >
                                                                                                    <?php echo e($item->title); ?> × <?php echo e($item->qty); ?>

                                                                                                </td>
                                                                                                <td
                                                                                                    class="Spacer Table-gap"
                                                                                                    width="8"
                                                                                                    style="
                                                                                                        border: 0;
                                                                                                        border-collapse: collapse;
                                                                                                        margin: 0;
                                                                                                        padding: 0;
                                                                                                        -webkit-font-smoothing: antialiased;
                                                                                                        -moz-osx-font-smoothing: grayscale;
                                                                                                        color: #ffffff;
                                                                                                        font-size: 1px;
                                                                                                        line-height: 1px;
                                                                                                        mso-line-height-rule: exactly;
                                                                                                    "
                                                                                                >
                                                                                                    &nbsp;
                                                                                                </td>
                                                                                                <td
                                                                                                    class="Table-amount Font Font--body"
                                                                                                    align="right"
                                                                                                    valign="top"
                                                                                                    style="
                                                                                                        border: 0;
                                                                                                        border-collapse: collapse;
                                                                                                        margin: 0;
                                                                                                        padding: 0;
                                                                                                        -webkit-font-smoothing: antialiased;
                                                                                                        -moz-osx-font-smoothing: grayscale;
                                                                                                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                                                        mso-line-height-rule: exactly;
                                                                                                        vertical-align: middle;
                                                                                                        color: #525f7f;
                                                                                                        font-size: 15px;
                                                                                                        line-height: 24px;
                                                                                                    "
                                                                                                >
                                                                                                    ৳<?php echo e($item->qty * $item->total_amount); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td
                                                                                                    class="Table-divider Spacer"
                                                                                                    colspan="3"
                                                                                                    height="6"
                                                                                                    style="
                                                                                                        border: 0;
                                                                                                        border-collapse: collapse;
                                                                                                        margin: 0;
                                                                                                        padding: 0;
                                                                                                        -webkit-font-smoothing: antialiased;
                                                                                                        -moz-osx-font-smoothing: grayscale;
                                                                                                        color: #ffffff;
                                                                                                        font-size: 1px;
                                                                                                        line-height: 1px;
                                                                                                        mso-line-height-rule: exactly;
                                                                                                    "
                                                                                                >
                                                                                                    &nbsp;
                                                                                                </td>
                                                                                            </tr>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                                        <tr>
                                                                                            <td
                                                                                                class="Table-divider Spacer"
                                                                                                colspan="3"
                                                                                                height="6"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    color: #ffffff;
                                                                                                    font-size: 1px;
                                                                                                    line-height: 1px;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                "
                                                                                            >
                                                                                                &nbsp;
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td
                                                                                                class="Table-divider Spacer"
                                                                                                colspan="3"
                                                                                                height="6"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    color: #ffffff;
                                                                                                    font-size: 1px;
                                                                                                    line-height: 1px;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                "
                                                                                            >
                                                                                                &nbsp;
                                                                                            </td>
                                                                                        </tr>

                                                                                        <tr>
                                                                                            <td
                                                                                                class="Spacer"
                                                                                                bgcolor="e6ebf1"
                                                                                                colspan="3"
                                                                                                height="1"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    color: #ffffff;
                                                                                                    font-size: 1px;
                                                                                                    line-height: 1px;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                "
                                                                                            >
                                                                                                &nbsp;
                                                                                            </td>
                                                                                        </tr>

                                                                                        <tr>
                                                                                            <td
                                                                                                class="Table-divider Spacer"
                                                                                                colspan="3"
                                                                                                height="8"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    color: #ffffff;
                                                                                                    font-size: 1px;
                                                                                                    line-height: 1px;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                "
                                                                                            >
                                                                                                &nbsp;
                                                                                            </td>
                                                                                        </tr>

                                                                                        <tr>
                                                                                            <td
                                                                                                class="Table-description Font Font--body"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                    vertical-align: middle;
                                                                                                    color: #525f7f;
                                                                                                    font-size: 15px;
                                                                                                    line-height: 24px;
                                                                                                    width: 100%;
                                                                                                "
                                                                                            >
                                                                                                <strong>Amount charged</strong>
                                                                                            </td>
                                                                                            <td
                                                                                                class="Spacer Table-gap"
                                                                                                width="8"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    color: #ffffff;
                                                                                                    font-size: 1px;
                                                                                                    line-height: 1px;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                "
                                                                                            >
                                                                                                &nbsp;
                                                                                            </td>
                                                                                            <td
                                                                                                class="Table-amount Font Font--body"
                                                                                                align="right"
                                                                                                valign="top"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                    vertical-align: middle;
                                                                                                    color: #525f7f;
                                                                                                    font-size: 15px;
                                                                                                    line-height: 24px;
                                                                                                "
                                                                                            >
                                                                                                <strong>৳<?php echo e($order->total_amount); ?></strong>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td
                                                                                                class="Table-divider Spacer"
                                                                                                colspan="3"
                                                                                                height="6"
                                                                                                style="
                                                                                                    border: 0;
                                                                                                    border-collapse: collapse;
                                                                                                    margin: 0;
                                                                                                    padding: 0;
                                                                                                    -webkit-font-smoothing: antialiased;
                                                                                                    -moz-osx-font-smoothing: grayscale;
                                                                                                    color: #ffffff;
                                                                                                    font-size: 1px;
                                                                                                    line-height: 1px;
                                                                                                    mso-line-height-rule: exactly;
                                                                                                "
                                                                                            >
                                                                                                &nbsp;
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </td>
                                                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="16">
                                                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td
                                                                                class="st-Spacer st-Spacer--blocksItemEnds"
                                                                                colspan="3"
                                                                                height="12"
                                                                                style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;"
                                                                            >
                                                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td class="st-Spacer st-Spacer--kill" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--stacked" colspan="3" height="16" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Divider st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--divider" colspan="3" height="20" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                            <td bgcolor="#e6ebf1" height="1" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--divider" colspan="3" height="31" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Copy st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                            <td
                                                style="
                                                    border: 0;
                                                    margin: 0;
                                                    padding: 0;
                                                    color: #525f7f !important;
                                                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
                                                    font-size: 16px;
                                                    line-height: 24px;
                                                "
                                            >
                                                If you have any questions, contact us at
                                                <a style="border: 0; margin: 0; padding: 0; color: #556cd6 !important; text-decoration: none;" href="mailto:support@foodmaker.com">support@foodmaker.com</a>.
                                            </td>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--stacked" colspan="3" height="12" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="st-Divider st-Width st-Width--mobile" border="0" cellpadding="0" cellspacing="0" width="600" style="min-width: 600px;">
                                    <tbody>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--divider" colspan="3" height="20" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                            <td bgcolor="#e6ebf1" height="1" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                            <td class="st-Spacer st-Spacer--gutter" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;" width="64">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="st-Spacer st-Spacer--divider" colspan="3" height="31" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; max-height: 1px; mso-line-height-rule: exactly;">
                                                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table class="Section Divider Divider--small" width="100%" style="border: 0; border-collapse: collapse; margin: 0; padding: 0; background-color: #ffffff;">
                                    <tbody>
                                        <tr>
                                            <td
                                                class="Spacer Spacer--divider"
                                                height="20"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    color: #ffffff;
                                                    font-size: 1px;
                                                    line-height: 1px;
                                                    mso-line-height-rule: exactly;
                                                "
                                            >
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <table
                                    class="Section Section--last Divider Divider--large"
                                    width="100%"
                                    style="border: 0; border-collapse: collapse; margin: 0; padding: 0; background-color: #ffffff; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;"
                                >
                                    <tbody>
                                        <tr>
                                            <td
                                                class="Spacer Spacer--divider"
                                                height="64"
                                                style="
                                                    border: 0;
                                                    border-collapse: collapse;
                                                    margin: 0;
                                                    padding: 0;
                                                    -webkit-font-smoothing: antialiased;
                                                    -moz-osx-font-smoothing: grayscale;
                                                    color: #ffffff;
                                                    font-size: 1px;
                                                    line-height: 1px;
                                                    mso-line-height-rule: exactly;
                                                "
                                            >
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <!-- /Wrapper -->
            </td>
        </tr>
        <tr>
            <td class="st-Spacer st-Spacer--emailEnd" height="64" style="border: 0; margin: 0; padding: 0; font-size: 1px; line-height: 1px; mso-line-height-rule: exactly;">
                <div class="st-Spacer st-Spacer--filler">&nbsp;</div>
            </td>
        </tr>
    </tbody>
</table>
<?php /**PATH D:\xampp\htdocs\personal\burger_maker\resources\views/mail/order_mail.blade.php ENDPATH**/ ?>