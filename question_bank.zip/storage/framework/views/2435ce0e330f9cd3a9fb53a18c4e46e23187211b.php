<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Invoice</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <style>
        @font-face{
            src: url('/bangla.ttf');
            font-family: bangla;
        }
        body{
            font-family: 'bangla',sans-serif;
            padding: 30px;
        }
        p{
            font-size: 19px;
        }
        table tr td:nth-child(2){
            text-align: right;
            padding-right: 56px;
        }
        .bg_sill{
            position: relative;
        }
        .bg_sill::before{
            position: absolute;
            content: 'approved';
            left: 30px;
            top: 50%;
            font-weight: 600;
            transform: translateY(-50%) rotate(-30deg);
            text-transform: uppercase;
            color: red;
            font-size: 23px;
            border: 1px solid red;
            padding: 5px;
            line-height: 23px;
            z-index: 99;
        }
        .not_bg_sill{
            position: relative;
        }
        .not_bg_sill::before{
            position: absolute;
            content: 'not approved';
            left: 70px;
            top: 50%;
            font-weight: 600;
            transform: translateY(-50%) rotate(-30deg );
            text-transform: uppercase;
            color: red;
            font-size: 18px;
            border: 1px solid red;
            padding: 5px;
            line-height: 23px;
            z-index: 99;
        }

        h4,h5,p{
            font-size: 24px;
            margin: 0;
        }

        .table thead th {
            border-bottom: unset;
            background: #d4f7ff;
        }

        .table th, .table td {
            border: 1px solid #288e9c;
        }

        @media  print {
            @page  {
                size: A4;
            }
            .not_bg_sill::before{
                -webkit-print-color-adjust: exact;
            }
            .bg_sill::before{
                -webkit-print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>
    <?php
        function en2bn($number) {
            $bn = array("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০");
            $en = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "0");
            return str_replace($en, $bn, $number);
        }
        $date=en2bn(request()->date);
        $voucher_no=en2bn(request()->voucher_no);
        $guest_name=request()->guest_name;
        $amount=en2bn(request()->amount);
        $amount_bangla=request()->amount_bangla;
        $program=request()->program;
    ?>
    <div class="row">
        <div class="col-12 text-center">
            <h1>ভাউচার</h1>
        </div>
        <div class="col-6">
            <h4><b>খাত : </b> সফর</h4>
            <h4><b>ক্রম : </b> <?php echo e($voucher_no); ?></h4>
        </div>
        <div class="col-6 text-right">
            <h4><b>তারিখ : </b> <?php echo e($date); ?></h4>
        </div>
    </div>
    <section style="min-height: 300px;" class="<?php echo e(1 ? 'bg_sill' : 'not_bg_sill'); ?>">
        <div class="row">
            <div class="col-12">
                <table class="table my-3">
                    <thead>
                        <tr>
                            <th style="text-align: center;"><h4>বিবরণ</h4></th>
                            <th style="text-align: center;"><h4>পরিমাণ</h4></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="width: 77%">
                                <p style="height: 200px;">
                                    মেহমান ( <?php echo e($guest_name); ?> )
                                    এর জন্য সফর ( <?php echo e($program); ?> ) বাবদ খরচ
                                </p>
                            </td>
                            <td>
                                <h5> ৳<?php echo e($amount); ?></h5>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>
                                <h4>মোট : </h4>
                            </td>
                            <td>
                                <h5 style="font-weight: 600;">৳<?php echo e($amount); ?></h5>
                            </td>
                        </tr>
                        <tr>
                            
                            <td colspan="2"><h4>কথায় : ( <?php echo e($amount_bangla); ?> )</h4></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </section>
    <section>
        <div class="row">
            <div class="col-12 text-right">
                <u style="font-size: 20px;padding-top: 37px;padding-right: 96px;display:inline-block">স্বাক্ষর</u>
            </div>
        </div>
    </section>

</body>
</html>

<?php /**PATH D:\xampp\htdocs\earthface\tada_laravel_vue\resources\views/invoice.blade.php ENDPATH**/ ?>