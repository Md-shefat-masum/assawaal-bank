<?php $__env->startSection('content'); ?>

<?php if(env('EMAIL_VERIFICATION') == false): ?>
    <div class="container">
        <div style="height: 100vh;" class="d-flex justify-content-center align-items-center align-content-center">
            <div class="card shadow border-0">
                <div class="card-body">
                    <form @submit.prevent="login($event)" autocomplete="off">
                    
                        <?php echo csrf_field(); ?>

                        

                        <div class="row mb-3">
                            <label for="email" class="col-md-12 col-form-label text-md-start"><?php echo e(__('Email Address')); ?></label>

                            <div class="col-md-12">
                                <input id="email" type="email" autocomplete="off" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                <p class="text-danger mb-0" v-if="email_error_message">{{email_error_message}}</p>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-12 col-form-label text-md-start"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-12">
                                <input id="password" type="password" autocomplete="off" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                <p class="text-danger mb-0" v-if="password_error_message">{{password_error_message}}</p>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-12 text-center ">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('cjs'); ?>
        <script defer>
            new Vue({
                el: '#app',
                created: function(){
                    $('#loader').toggleClass('d-none');
                    setTimeout(() => {
                        $('form').trigger('reset');
                    }, 600);
                },
                data: function(){
                    return {
                        mode: 'login',
                        code_start_time: null,
                        left_time_min: 0,
                        left_time_sec: 0,
                        code_error_message: null,
                        email_error_message: null,
                        password_error_message: null,
                        error_message: null,
                        success_message: null,
                    }
                },
                methods: {
                    login: function(event){
                        $('#loader').toggleClass('d-none');
                        let formData = new FormData(event.target);
                        this.email_error_message = null;
                        this.password_error_message = null;
                        axios.post('/api/v1/user/api-login',formData)
                            .then(res=>{
                                // console.log(res.data);
                                setTimeout(() => {
                                    $('form').trigger('reset');
                                }, 600);
                                $('#loader').toggleClass('d-none');

                                window.localStorage.setItem('token',res.data.access_token);
                                window.localStorage.setItem('user',JSON.stringify(res.data.user));
                                localStorage.setItem('last_time',new moment());
                                window.location = '/dashboard';
                            })
                            .catch(err=>{
                                console.log(err.response);
                                $('#loader').toggleClass('d-none');
                                this.email_error_message = err.response.data?.data?.email[0];
                                this.password_error_message = err.response.data?.data?.password[0];
                                this.error_message = err.response.data.message;
                            })
                    },
                }
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <?php echo $__env->make('auth.login_verify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\personal\question_bank\resources\views/auth/login.blade.php ENDPATH**/ ?>